
package codeDeveloper;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class textfield1 extends JFrame{

    private JTextField tfname;
    
    private JLabel lblName;
    
    private JButton btnSave;
    
    private JPanel pnlPanel;
    public textfield1() {
        
        pnlPanel=new JPanel();
        tfname=new JTextField(40);
        lblName=new JLabel("enter your name:");
        btnSave=new JButton("save name");
        
        
        this.add(pnlPanel);
        pnlPanel.add(lblName);
        pnlPanel.add(tfname);
        pnlPanel.add(btnSave);
        
    this.setVisible(true);
    this.setSize(500, 150);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setTitle("FIND NAME");
    }
    
}
